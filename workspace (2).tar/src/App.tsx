import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import {
  Menu, X, ArrowRight, ChevronDown,
  Megaphone, Globe, Cpu, Target, Layers, Zap,
  MessageCircle, Instagram, Facebook,
  Check, XCircle, Send
} from 'lucide-react';

// WhatsApp URL
const WHATSAPP_URL = "https://wa.me/923325564406?text=Hi%20CreateShot%2C%20I%27d%20like%20to%20discuss%20how%20you%20can%20help%20my%20business%20grow.";

// Logo URL
const LOGO_URL = "https://image.qwenlm.ai/generated-images/7f609f1b-7e9d-4219-8a2d-f1574f421426/_result.png";

// Animation variants
const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const stagger = {
  visible: { transition: { staggerChildren: 0.1 } }
};

// Section wrapper with scroll animation
function AnimatedSection({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.6, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

// Navigation
function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Growth System', href: '#growth-system' },
    { label: 'Services', href: '#services' },
    { label: 'Industries', href: '#industries' },
    { label: 'How It Works', href: '#how-it-works' },
    { label: 'What We Build', href: '#systems' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2">
            <img src={LOGO_URL} alt="CreateShot" className="h-8 lg:h-10 w-auto" />
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden lg:block">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-brand text-white text-sm font-semibold rounded-lg hover:bg-brand-dark transition-colors"
            >
              Get Your Growth Strategy
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 text-gray-600 hover:text-gray-900"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:hidden bg-white border-b border-gray-100 shadow-lg"
        >
          <div className="px-4 py-6 space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block text-base font-medium text-gray-700 hover:text-brand transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center px-5 py-3 bg-brand text-white font-semibold rounded-lg hover:bg-brand-dark transition-colors mt-4"
            >
              Get Your Growth Strategy
            </a>
          </div>
        </motion.div>
      )}
    </nav>
  );
}

// Hero Section
function Hero() {
  return (
    <section className="relative min-h-screen flex items-center bg-dark overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-dark via-dark-secondary to-dark" />
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-brand/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-brand/3 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 lg:py-40">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-brand text-sm font-medium tracking-wider uppercase mb-6"
            >
              Content • Ads • Websites • AI • Automation
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6"
            >
              Turn Attention Into{' '}
              <span className="text-brand">Customers.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-gray-400 leading-relaxed mb-8 max-w-xl"
            >
              CreateShot builds growth systems that help businesses attract the right audience, convert more leads, and automate the customer journey.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-brand text-white font-semibold rounded-lg hover:bg-brand-dark transition-all hover:shadow-lg hover:shadow-brand/20"
              >
                Get Your Growth Strategy
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#growth-system"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 border border-gray-600 text-gray-300 font-semibold rounded-lg hover:border-brand hover:text-brand transition-colors"
              >
                See How It Works
                <ChevronDown className="w-4 h-4" />
              </a>
            </motion.div>
          </div>

          {/* Right Visual - Growth System Diagram */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="hidden lg:block"
          >
            <HeroVisual />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Hero Visual - Abstract Growth System
function HeroVisual() {
  return (
    <div className="relative">
      <div className="bg-dark-secondary border border-gray-800 rounded-2xl p-8">
        {/* System Flow */}
        <div className="space-y-4">
          {/* Attract */}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center">
              <Target className="w-5 h-5 text-brand" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-brand uppercase tracking-wider">ATTRACT</span>
                <div className="flex-1 h-px bg-gradient-to-r from-brand/40 to-transparent" />
              </div>
              <p className="text-sm text-gray-400 mt-1">Audience Growth</p>
            </div>
          </div>

          {/* Connector */}
          <div className="flex justify-center">
            <div className="w-px h-8 bg-gradient-to-b from-brand/40 to-brand/20" />
          </div>

          {/* Convert */}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center">
              <Layers className="w-5 h-5 text-brand" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-brand uppercase tracking-wider">CONVERT</span>
                <div className="flex-1 h-px bg-gradient-to-r from-brand/40 to-transparent" />
              </div>
              <p className="text-sm text-gray-400 mt-1">Conversion Experience</p>
            </div>
          </div>

          {/* Connector */}
          <div className="flex justify-center">
            <div className="w-px h-8 bg-gradient-to-b from-brand/40 to-brand/20" />
          </div>

          {/* Automate */}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center">
              <Cpu className="w-5 h-5 text-brand" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-brand uppercase tracking-wider">AUTOMATE</span>
                <div className="flex-1 h-px bg-gradient-to-r from-brand/40 to-transparent" />
              </div>
              <p className="text-sm text-gray-400 mt-1">AI & Workflow</p>
            </div>
          </div>
        </div>

        {/* Bottom label */}
        <div className="mt-8 pt-6 border-t border-gray-800">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-brand animate-pulse-subtle" />
            <span className="text-xs text-gray-500">Connected Growth System</span>
          </div>
        </div>
      </div>

      {/* Floating accent */}
      <div className="absolute -top-3 -right-3 w-6 h-6 rounded-full bg-brand/20 border border-brand/30" />
      <div className="absolute -bottom-2 -left-2 w-4 h-4 rounded-full bg-brand/10 border border-brand/20" />
    </div>
  );
}

// Problem Section
function ProblemSection() {
  const problems = [
    {
      num: '01',
      title: 'Attention without conversion',
      desc: 'You get views and clicks, but they don\'t turn into qualified leads or conversations.'
    },
    {
      num: '02',
      title: 'Tools that don\'t talk to each other',
      desc: 'Content, ads, website, and follow-up live in silos. Leads slip through the cracks.'
    },
    {
      num: '03',
      title: 'Manual follow-up kills momentum',
      desc: 'Slow response and manual nurturing means hot prospects can go cold before you respond.'
    },
    {
      num: '04',
      title: 'No clear growth engine',
      desc: 'Marketing feels random. There\'s no clear system to measure, improve, and scale.'
    }
  ];

  return (
    <section className="py-20 lg:py-32 bg-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="max-w-3xl mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">THE PROBLEM</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
              Your Marketing Should Work as a System.
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              More followers, random ads, and disconnected tools don't create growth. Growth comes from a connected system that turns attention into customers.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 gap-6">
          {problems.map((problem, i) => (
            <AnimatedSection key={problem.num} delay={i * 0.1}>
              <div className="group p-6 lg:p-8 bg-white border border-gray-border rounded-xl hover:border-brand/30 hover:shadow-md transition-all">
                <div className="flex items-start gap-4">
                  <span className="text-3xl font-bold text-brand/20 group-hover:text-brand/40 transition-colors">
                    {problem.num}
                  </span>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{problem.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{problem.desc}</p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

// Growth System Section
function GrowthSystemSection() {
  const stages = [
    {
      num: '01',
      label: 'ATTRACT',
      title: 'Get the right people to discover you',
      desc: 'Build consistent reach with the people most likely to become customers.',
      services: ['Social Media Marketing', 'Content Creation', 'Paid Advertising', 'Influencer Marketing', 'Audience Growth'],
      systemLabel: 'Audience Growth',
      icon: <Target className="w-6 h-6" />
    },
    {
      num: '02',
      label: 'CONVERT',
      title: 'Turn attention into qualified leads',
      desc: 'Design conversion experiences that guide interest into conversations.',
      services: ['Websites', 'Landing Pages', 'Web Development', 'App Development', 'Conversion Systems', 'Email Marketing'],
      systemLabel: 'Conversion Experience',
      icon: <Layers className="w-6 h-6" />
    },
    {
      num: '03',
      label: 'AUTOMATE',
      title: 'Make the journey faster and more reliable',
      desc: 'Automate qualification, follow-up, and booking so opportunities don\'t depend entirely on manual work.',
      services: ['AI Customer Systems', 'Lead Qualification', 'Automated Follow-up', 'Customer Support Automation', 'Business Workflows'],
      systemLabel: 'AI & Workflow',
      icon: <Cpu className="w-6 h-6" />
    }
  ];

  return (
    <section id="growth-system" className="py-20 lg:py-32 bg-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="text-center max-w-3xl mx-auto mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">THE SYSTEM</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              The CreateShot Growth System
            </h2>
            <p className="text-lg text-gray-400">
              Three connected stages. One growth engine.
            </p>
          </div>
        </AnimatedSection>

        {/* Desktop: Horizontal with connectors */}
        <div className="hidden lg:grid lg:grid-cols-[1fr_auto_1fr_auto_1fr] gap-0 items-stretch">
          {stages.map((stage, i) => (
            <div key={stage.label} className="contents">
              <AnimatedSection delay={i * 0.15}>
                <div className="h-full bg-dark-secondary border border-gray-800 rounded-xl p-8 hover:border-brand/30 transition-all group">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center text-brand group-hover:bg-brand/20 transition-colors">
                      {stage.icon}
                    </div>
                    <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Stage {stage.num}</span>
                  </div>

                  <div className="mb-4">
                    <span className="text-brand text-sm font-bold tracking-wider">{stage.label}</span>
                  </div>

                  <h3 className="text-xl font-semibold text-white mb-3">{stage.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed mb-6">{stage.desc}</p>

                  <div className="space-y-2 mb-6">
                    {stage.services.map((service) => (
                      <div key={service} className="flex items-center gap-2 text-sm text-gray-400">
                        <div className="w-1.5 h-1.5 rounded-full bg-brand/60" />
                        {service}
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 border-t border-gray-800">
                    <span className="text-xs font-medium text-brand/70 uppercase tracking-wider">{stage.systemLabel}</span>
                  </div>
                </div>
              </AnimatedSection>

              {/* Connector arrow between cards */}
              {i < 2 && (
                <div className="flex items-center justify-center px-4">
                  <div className="flex items-center">
                    <div className="w-8 h-px bg-gradient-to-r from-brand/60 to-brand" />
                    <ArrowRight className="w-4 h-4 text-brand" />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Mobile: Vertical with connectors */}
        <div className="lg:hidden space-y-0">
          {stages.map((stage, i) => (
            <div key={stage.label}>
              <AnimatedSection delay={i * 0.15}>
                <div className="bg-dark-secondary border border-gray-800 rounded-xl p-6 hover:border-brand/30 transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center text-brand">
                      {stage.icon}
                    </div>
                    <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">Stage {stage.num}</span>
                  </div>

                  <div className="mb-3">
                    <span className="text-brand text-sm font-bold tracking-wider">{stage.label}</span>
                  </div>

                  <h3 className="text-lg font-semibold text-white mb-2">{stage.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed mb-4">{stage.desc}</p>

                  <div className="space-y-2 mb-4">
                    {stage.services.map((service) => (
                      <div key={service} className="flex items-center gap-2 text-sm text-gray-400">
                        <div className="w-1.5 h-1.5 rounded-full bg-brand/60" />
                        {service}
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-gray-800">
                    <span className="text-xs font-medium text-brand/70 uppercase tracking-wider">{stage.systemLabel}</span>
                  </div>
                </div>
              </AnimatedSection>

              {/* Vertical connector */}
              {i < 2 && (
                <div className="flex justify-center py-4">
                  <div className="flex flex-col items-center">
                    <div className="w-px h-6 bg-gradient-to-b from-brand/60 to-brand" />
                    <ChevronDown className="w-4 h-4 text-brand" />
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Services Section
function ServicesSection() {
  const services = [
    {
      num: '01',
      title: 'Marketing & Growth',
      icon: <Megaphone className="w-6 h-6" />,
      items: ['Social Media Marketing', 'Content Creation', 'Paid Advertising', 'Influencer Marketing', 'Email Marketing']
    },
    {
      num: '02',
      title: 'Digital Experiences',
      icon: <Globe className="w-6 h-6" />,
      items: ['Websites & Landing Pages', 'Web Development', 'App Development', 'Conversion Systems', 'UI/UX & Funnels']
    },
    {
      num: '03',
      title: 'AI & Automation',
      icon: <Cpu className="w-6 h-6" />,
      items: ['AI Customer Systems', 'Lead Qualification', 'Automated Follow-up', 'Customer Support Automation', 'Workflow Automation']
    }
  ];

  return (
    <section id="services" className="py-20 lg:py-32 bg-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="max-w-3xl mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">SERVICES</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              What We Build
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              Whether you need one component or a complete growth system, we build it to work together.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <AnimatedSection key={service.num} delay={i * 0.1}>
              <div className="h-full bg-white border border-gray-border rounded-xl p-8 hover:border-brand/30 hover:shadow-md transition-all group">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center text-brand group-hover:bg-brand/20 transition-colors">
                    {service.icon}
                  </div>
                  <span className="text-sm font-medium text-gray-400">{service.num}</span>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-6">{service.title}</h3>

                <div className="space-y-3">
                  {service.items.map((item) => (
                    <div key={item} className="flex items-center gap-3 text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-brand" />
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        <AnimatedSection delay={0.3}>
          <div className="mt-12 max-w-2xl">
            <p className="text-gray-600 leading-relaxed">
              We don't start with a list of services. We start with the business problem and build the right combination of systems around it.
            </p>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Industries Section
function IndustriesSection() {
  const industries = [
    { name: 'SaaS', desc: 'Acquisition, activation & lifecycle systems', solves: ['Acquisition', 'Activation', 'Lifecycle'] },
    { name: 'Real Estate', desc: 'Lead generation, qualification & follow-up', solves: ['Qualified inquiries', 'Faster response', 'Automated follow-up'] },
    { name: 'Dental & Clinics', desc: 'Patient acquisition & appointment conversion', solves: ['Patient acquisition', 'Appointment conversion', 'Follow-up'] },
    { name: 'E-commerce & DTC', desc: 'Acquisition, conversion & retention', solves: ['Customer acquisition', 'Conversion', 'Retention'] },
    { name: 'Home Services & HVAC', desc: 'Local leads & automated follow-up', solves: ['Local demand', 'Lead response', 'Follow-up'] },
    { name: 'Fitness & Gyms', desc: 'Lead generation & membership conversion', solves: ['Lead generation', 'Qualification', 'Membership conversion'] },
    { name: 'Financial Coaches', desc: 'Lead qualification, nurturing & booking', solves: ['Lead qualification', 'Nurturing', 'Consultation booking'] },
    { name: 'Restaurants', desc: 'Local acquisition & customer retention', solves: ['Local discovery', 'Customer acquisition', 'Repeat engagement'] },
    { name: 'Law Firms', desc: 'Qualified inquiry generation & conversion', solves: ['High-intent inquiries', 'Conversion', 'Follow-up'] },
    { name: 'Med Spas & Aesthetic Clinics', desc: 'Lead generation, booking & follow-up', solves: ['Lead generation', 'Booking', 'Follow-up'] },
  ];

  return (
    <section id="industries" className="py-20 lg:py-32 bg-light-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="max-w-3xl mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">INDUSTRIES</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              Built for ambitious businesses ready to grow.
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              Different businesses have different bottlenecks. We connect the right acquisition, conversion, and automation systems around the business model.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {industries.map((industry, i) => (
            <AnimatedSection key={industry.name} delay={i * 0.05}>
              <div className="h-full bg-white border border-gray-border rounded-xl p-5 hover:border-brand/30 hover:shadow-sm transition-all group">
                <h3 className="text-base font-semibold text-gray-900 mb-1 group-hover:text-brand transition-colors">{industry.name}</h3>
                <p className="text-sm text-gray-500 mb-3">{industry.desc}</p>
                <div className="pt-3 border-t border-gray-100">
                  <p className="text-xs font-medium text-gray-400 uppercase tracking-wider mb-2">What we solve:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {industry.solves.map((item) => (
                      <span key={item} className="text-xs px-2 py-0.5 bg-brand/5 text-brand border border-brand/10 rounded">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

// Why CreateShot Section
function WhySection() {
  const reasons = [
    {
      title: 'Strategy Before Execution',
      desc: 'We map your current acquisition, conversion, and follow-up before building anything. No guesswork.'
    },
    {
      title: 'One System, Multiple Capabilities',
      desc: 'One connected team across marketing, digital experiences, and AI automation.'
    },
    {
      title: 'Built Around Your Business',
      desc: 'Every system is shaped around your offer, audience, and bottleneck — not a templated package.'
    },
    {
      title: 'Designed To Improve',
      desc: 'Your growth system is built to be measured, tested, and optimized over time.'
    }
  ];

  return (
    <section className="py-20 lg:py-32 bg-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="max-w-3xl mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">WHY CREATESHOT</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              We Don't Just Execute. We Diagnose.
            </h2>
          </div>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 gap-6">
          {reasons.map((reason, i) => (
            <AnimatedSection key={reason.title} delay={i * 0.1}>
              <div className="p-8 bg-white border border-gray-border rounded-xl hover:border-brand/30 hover:shadow-md transition-all">
                <div className="w-8 h-8 rounded-lg bg-brand/10 border border-brand/30 flex items-center justify-center mb-4">
                  <Zap className="w-4 h-4 text-brand" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{reason.title}</h3>
                <p className="text-gray-600 leading-relaxed">{reason.desc}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

// How It Works Section
function HowItWorksSection() {
  const steps = [
    { num: '01', title: 'Diagnose', desc: 'We audit how you currently attract, convert, and follow up. We identify the biggest bottleneck.' },
    { num: '02', title: 'Build', desc: 'We design the right combination of content, ads, digital experiences, and AI automation around the problem.' },
    { num: '03', title: 'Launch', desc: 'We connect the system and put the experience live.' },
    { num: '04', title: 'Optimize', desc: 'We measure, test, improve, and refine the system over time.' },
  ];

  return (
    <section id="how-it-works" className="py-20 lg:py-32 bg-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="text-center max-w-3xl mx-auto mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">PROCESS</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-white">
              From Problem To Growth System
            </h2>
          </div>
        </AnimatedSection>

        {/* Desktop: Horizontal with connecting line */}
        <div className="hidden lg:block">
          <div className="relative">
            {/* Connecting line */}
            <div className="absolute top-8 left-[12.5%] right-[12.5%] h-px bg-gradient-to-r from-brand/20 via-brand/40 to-brand/20" />

            <div className="grid grid-cols-4 gap-8">
              {steps.map((step, i) => (
                <AnimatedSection key={step.num} delay={i * 0.15}>
                  <div className="text-center relative">
                    <div className="w-16 h-16 rounded-full bg-dark-secondary border-2 border-brand/30 flex items-center justify-center mx-auto mb-6 relative z-10">
                      <span className="text-brand font-bold text-lg">{step.num}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">{step.title}</h3>
                    <p className="text-sm text-gray-400 leading-relaxed">{step.desc}</p>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile: Vertical */}
        <div className="lg:hidden space-y-0">
          {steps.map((step, i) => (
            <div key={step.num}>
              <AnimatedSection delay={i * 0.1}>
                <div className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full bg-dark-secondary border-2 border-brand/30 flex items-center justify-center shrink-0">
                      <span className="text-brand font-bold text-sm">{step.num}</span>
                    </div>
                    {i < 3 && <div className="w-px flex-1 bg-gradient-to-b from-brand/40 to-brand/10 mt-2" />}
                  </div>
                  <div className="pb-8">
                    <h3 className="text-lg font-semibold text-white mb-2">{step.title}</h3>
                    <p className="text-sm text-gray-400 leading-relaxed">{step.desc}</p>
                  </div>
                </div>
              </AnimatedSection>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// What We Build - Systems Section
function SystemsSection() {
  const systems = [
    {
      num: 'SYSTEM 01',
      title: 'Growth System',
      label: 'CreateShot-designed system',
      flow: 'ATTRACT → CONVERT → AUTOMATE',
      desc: 'A connected growth system combining audience acquisition, conversion experiences, and automated customer journeys.'
    },
    {
      num: 'SYSTEM 02',
      title: 'Conversion Experience',
      label: 'CreateShot-designed framework',
      flow: 'Traffic → Landing Page → Lead → Customer',
      desc: 'A conversion framework designed to turn incoming attention into qualified conversations.'
    },
    {
      num: 'SYSTEM 03',
      title: 'AI Customer System',
      label: 'CreateShot-designed workflow',
      flow: 'Lead → Qualification → Follow-up → Booking',
      desc: 'An AI-powered workflow designed to qualify prospects, follow up quickly, and move qualified leads toward a conversation.'
    }
  ];

  return (
    <section id="systems" className="py-20 lg:py-32 bg-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="max-w-3xl mb-16">
            <p className="text-brand text-sm font-medium tracking-wider uppercase mb-4">CREATE SHOT SYSTEMS</p>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
              What We Build
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              Explore examples of the systems and workflows CreateShot designs.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-3 gap-6">
          {systems.map((system, i) => (
            <AnimatedSection key={system.num} delay={i * 0.1}>
              <div className="h-full bg-white border border-gray-border rounded-xl p-8 hover:border-brand/30 hover:shadow-md transition-all group">
                <div className="mb-4">
                  <span className="text-xs font-medium text-brand uppercase tracking-wider">{system.num}</span>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mb-2">{system.title}</h3>
                <p className="text-xs text-gray-400 uppercase tracking-wider mb-4">{system.label}</p>

                {/* Flow visualization */}
                <div className="bg-light-secondary border border-gray-100 rounded-lg p-4 mb-4">
                  <p className="text-sm font-medium text-gray-700">{system.flow}</p>
                </div>

                <p className="text-sm text-gray-600 leading-relaxed">{system.desc}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

// Fit Section
function FitSection() {
  const goodFit = [
    'Want a system, not random marketing tasks',
    'Are ready to invest in growth infrastructure',
    'Have a product, service, or business model with room to grow',
    'Want content, ads, website and AI working together',
    'Are open to improving the customer journey'
  ];

  const notFit = [
    'Just want cheap followers or viral posts',
    'Expect overnight results without foundation',
    'Want a single post or logo without strategy',
    'Aren\'t ready to improve follow-up and sales processes'
  ];

  return (
    <section className="py-20 lg:py-32 bg-light-secondary">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">
              Is CreateShot Right For You?
            </h2>
          </div>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Good Fit */}
          <AnimatedSection delay={0.1}>
            <div className="h-full bg-white border border-brand/20 rounded-xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-full bg-brand/10 flex items-center justify-center">
                  <Check className="w-4 h-4 text-brand" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">We're a good fit if you:</h3>
              </div>
              <ul className="space-y-3">
                {goodFit.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <Check className="w-4 h-4 text-brand mt-0.5 shrink-0" />
                    <span className="text-gray-600 text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </AnimatedSection>

          {/* Not a Fit */}
          <AnimatedSection delay={0.2}>
            <div className="h-full bg-white border border-gray-border rounded-xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                  <XCircle className="w-4 h-4 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900">We're not a fit if you:</h3>
              </div>
              <ul className="space-y-3">
                {notFit.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <XCircle className="w-4 h-4 text-gray-300 mt-0.5 shrink-0" />
                    <span className="text-gray-500 text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

// Primary CTA Section
function PrimaryCTASection() {
  return (
    <section id="contact" className="py-20 lg:py-32 bg-dark">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <AnimatedSection>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Let's Find Your Biggest Growth Bottleneck.
          </h2>
          <p className="text-lg text-gray-400 leading-relaxed mb-4">
            Tell us where your business is today, what you're already doing, and where growth is stuck.
          </p>
          <p className="text-gray-500 mb-10">
            We'll identify the biggest bottleneck across your acquisition, conversion, or follow-up system.
          </p>

          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-brand text-white font-semibold rounded-lg hover:bg-brand-dark transition-all hover:shadow-lg hover:shadow-brand/20 text-lg"
          >
            <MessageCircle className="w-5 h-5" />
            Talk to CreateShot on WhatsApp
          </a>

          <div className="mt-8">
            <a href="mailto:createshot.agency@proton.me" className="text-gray-400 hover:text-brand transition-colors text-sm">
              createshot.agency@proton.me
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Final CTA Section
function FinalCTASection() {
  return (
    <section className="py-20 lg:py-32 bg-light">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <AnimatedSection>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">
            Build Something That Grows.
          </h2>
          <p className="text-lg text-gray-600 leading-relaxed mb-10">
            Your business doesn't need more random marketing. It needs the right system working together.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-brand text-white font-semibold rounded-lg hover:bg-brand-dark transition-all hover:shadow-lg hover:shadow-brand/20"
            >
              Get Your Growth Strategy
              <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:border-brand hover:text-brand transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              Talk to CreateShot
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  return (
    <footer className="bg-dark border-t border-gray-800 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <img src={LOGO_URL} alt="CreateShot" className="h-10 w-auto mb-4" />
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              Growth systems for modern businesses.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Contact</h4>
            <div className="space-y-2">
              <a href="mailto:createshot.agency@proton.me" className="block text-sm text-gray-400 hover:text-brand transition-colors">
                createshot.agency@proton.me
              </a>
              <a href="tel:+923325564406" className="block text-sm text-gray-400 hover:text-brand transition-colors">
                +92 332 5564406
              </a>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="block text-sm text-gray-400 hover:text-brand transition-colors"
              >
                WhatsApp
              </a>
            </div>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Follow</h4>
            <div className="space-y-2">
              <a
                href="https://www.instagram.com/createshot.agency/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-gray-400 hover:text-brand transition-colors"
              >
                <Instagram className="w-4 h-4" />
                Instagram
              </a>
              <a
                href="https://www.facebook.com/profile.php?id=61591872742861"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-gray-400 hover:text-brand transition-colors"
              >
                <Facebook className="w-4 h-4" />
                Facebook
              </a>
              <a
                href="https://www.threads.com/@createshot.agency"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-gray-400 hover:text-brand transition-colors"
              >
                <Send className="w-4 h-4" />
                Threads
              </a>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">
              © 2026 CreateShot. All rights reserved.
            </p>

            <div className="flex items-center gap-6">
              <a href="#" className="text-sm text-gray-500 hover:text-gray-300 transition-colors">Privacy Policy</a>
              <a href="#" className="text-sm text-gray-500 hover:text-gray-300 transition-colors">Terms & Conditions</a>
            </div>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm font-medium text-gray-600 tracking-wider">
              ATTRACT • CONVERT • AUTOMATE
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

// Floating WhatsApp Button
function FloatingWhatsApp() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => setVisible(window.scrollY > 300);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <motion.a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:shadow-xl hover:scale-105 transition-all"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle className="w-6 h-6 text-white" />
    </motion.a>
  );
}

// Main App
export default function App() {
  return (
    <div className="min-h-screen bg-light">
      <Navigation />
      <Hero />
      <ProblemSection />
      <GrowthSystemSection />
      <ServicesSection />
      <IndustriesSection />
      <WhySection />
      <HowItWorksSection />
      <SystemsSection />
      <FitSection />
      <PrimaryCTASection />
      <FinalCTASection />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
